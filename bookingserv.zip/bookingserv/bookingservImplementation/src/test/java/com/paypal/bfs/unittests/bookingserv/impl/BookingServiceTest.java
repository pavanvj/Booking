package com.paypal.bfs.unittests.bookingserv.impl;

import static org.mockito.Mockito.doReturn;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.paypal.bfs.test.bookingserv.api.dto.CreateBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.dto.GetBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.impl.BookingResourceImpl;
import com.paypal.bfs.test.bookingserv.repo.IBookingRepo;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ BookingResourceImpl.class})
public class BookingServiceTest {
	private BookingResourceImpl bookingService;
	  @Before
	    public void setUp() {
	        MockitoAnnotations.initMocks(this); 
	        bookingService = new BookingResourceImpl();
	    }
	
	@Mock
	private IBookingRepo bookingrepo;
	@SuppressWarnings("deprecation")
	@Test
	public void validDateTimeFormat() throws ParseException {
		boolean isValid = BookingResourceImpl.isValidFormat("dd/MM/yyyy", "12/12/2021");
		org.junit.Assert.assertEquals(true, isValid);
	}

	@Test
	public void invalidDateTimeFormat() throws ParseException {
		boolean isValid = BookingResourceImpl.isValidFormat("dd/MM/yyyy", "121/12/2021");
		org.junit.Assert.assertEquals(false, isValid);
	}
//	@Test
//	public void getAllBookingsSuccess() throws Exception {
//		PowerMockito.mockStatic(BookingResourceImpl.class);
//		Booking booking = new Booking();
//		booking.setId(1);
//		BookingResourceImpl bookingService = new BookingResourceImpl();
//		List<Booking> bookings  = new ArrayList<>();
//		PowerMockito.doReturn(bookings).when(bookingrepo).findAll();
//		doReturn(bookings).when(bookingrepo).findAll();
//		ResponseEntity<GetBookingResponseDTO> actualResponse = bookingService.GetAllBookings();
//		org.junit.Assert.assertEquals(HttpStatus.OK, actualResponse.getStatusCode());
//	}
//	@Test
//	public void createBookingFailed() throws Exception {
//		PowerMockito.mockStatic(BookingResourceImpl.class);
//		Booking booking = new Booking();
//		booking.setId(1);
//		BookingResourceImpl bookingService = new BookingResourceImpl();
//		Optional<Booking> booking1 = Optional.of(booking);
//		PowerMockito.doReturn(booking1).when(bookingrepo).findById(booking.getId());
//		ResponseEntity<CreateBookingResponseDTO> actualResponse = bookingService.createBooking(booking);
//		org.junit.Assert.assertEquals(HttpStatus.BAD_REQUEST, actualResponse.getStatusCode());
//	}
}
