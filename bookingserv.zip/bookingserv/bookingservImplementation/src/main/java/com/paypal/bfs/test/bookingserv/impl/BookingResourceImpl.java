package com.paypal.bfs.test.bookingserv.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.dto.CreateBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.dto.GetBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.exceptions.ErrorMessage;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.exceptions.CreateBookingFailedException;
import com.paypal.bfs.test.bookingserv.exceptions.NoBookingFoundException;
import com.paypal.bfs.test.bookingserv.repo.IBookingRepo;

@RestController
public class BookingResourceImpl implements BookingResource {


    	@Autowired
    	private IBookingRepo bookingRepository;

    	@Override
    	public ResponseEntity<GetBookingResponseDTO> GetAllBookings() {
    		List<Booking> bookings = new ArrayList<>();
    		bookings = bookingRepository.findAll();
    		GetBookingResponseDTO getBookingResponseDTO = new GetBookingResponseDTO();
    		getBookingResponseDTO.setBooking(bookings);
    		return new ResponseEntity<>(getBookingResponseDTO, HttpStatus.OK);
    	}

    	@Override
    	public ResponseEntity<CreateBookingResponseDTO> createBooking(Booking bookingRequestDTO) {
    		try {
    			checkIfBookingExist(bookingRequestDTO);
    		} catch (CreateBookingFailedException createEmpFailedException) {
    			CreateBookingResponseDTO createBookingResponseDTO = new CreateBookingResponseDTO();
    			createBookingResponseDTO.setError(new ErrorMessage(createEmpFailedException.getMessage(), createEmpFailedException.getErrorCode()));
    			return new ResponseEntity<>(createBookingResponseDTO, HttpStatus.BAD_REQUEST);
    		}
    		Booking bookingToSave = new Booking();
    		bookingToSave.setId(bookingRequestDTO.getId());
    		bookingToSave.setFirstName(bookingRequestDTO.getFirstName());
    		bookingToSave.setLastName(bookingRequestDTO.getLastName());

    		try {
    			if (!isValidFormat("dd/MM/yyyy", bookingRequestDTO.getDateOfBirth()))
    				return populateInvalidDateResponse("Invalid Date Format. Allowed Date Format: dd/MM/yyyy");
    			else
    				bookingToSave.setDateOfBirth(bookingRequestDTO.getDateOfBirth());
    		} catch (ParseException e) {
    			return populateInvalidDateResponse("Invalid Date Format. Allowed Date Format: dd/MM/yyyy");
    		}

    		bookingToSave.setAddress(bookingRequestDTO.getAddress());
    		try {
    			if (!isValidFormat("dd/MM/yyyy HH:mm:ss", bookingRequestDTO.getCheckinDateTime()))
    				return populateInvalidDateResponse("Invalid Checkin Date Format. Allowed Date Format: dd/MM/yyyy HH:mm:ss");
    			else
    				bookingToSave.setCheckinDateTime(bookingRequestDTO.getCheckinDateTime());
    		} catch (ParseException e) {
    			return populateInvalidDateResponse("Invalid Checkin Format. Allowed Date Format: dd/MM/yyyy HH:mm:ss");
    		}
    		try {
    			if (!isValidFormat("dd/MM/yyyy HH:mm:ss", bookingRequestDTO.getCheckoutDateTime()))
    				return populateInvalidDateResponse("Invalid Checkout Format. Allowed Date Format: dd/MM/yyyy HH:mm:ss");
    			else
    				bookingToSave.setCheckoutDateTime(bookingRequestDTO.getCheckoutDateTime());
    		} catch (ParseException e) {
    			return populateInvalidDateResponse("Invalid Checkout Format. Allowed Date Format: dd/MM/yyyy hh:MM:ss");
    		}
    		
    		
    		bookingToSave.setDeposit(bookingRequestDTO.getDeposit());
    		bookingToSave.setTotalPrice(bookingRequestDTO.getTotalPrice());
    		bookingRepository.save(bookingToSave);

    		return new ResponseEntity<>(new CreateBookingResponseDTO(), HttpStatus.CREATED);
    	}

    	public void checkIfBookingExist(Booking bookingRequestDTO) throws CreateBookingFailedException {
    		Optional<Booking> booking = bookingRepository.findById(bookingRequestDTO.getId());
    		if (booking.isPresent()) {
    			throw new CreateBookingFailedException("Booking ID: " + bookingRequestDTO.getId() + " already exists", "EMP_EXISTS");
    		}
    	}

    	private ResponseEntity<CreateBookingResponseDTO> populateInvalidDateResponse(String msg) {
    		CreateBookingResponseDTO createBookingResponseDTO = new CreateBookingResponseDTO();
    		createBookingResponseDTO.setError(new ErrorMessage(msg, "INV_DOB"));
    		return new ResponseEntity<>(createBookingResponseDTO, HttpStatus.BAD_REQUEST);
    	}

    	public static boolean isValidFormat(String format, String value) throws ParseException {
    		Date date = null;
    		SimpleDateFormat sdf = new SimpleDateFormat(format);
    		date = sdf.parse(value);
    		if (!value.equals(sdf.format(date))) {
    			date = null;
    		}

    		return date != null;
    	}
    	
//    	@Override
//    	public ResponseEntity<GetBookingResponseDTO> bookingGetById(String id) {
//    		Optional<Booking> booking = bookingRepository.findById(Integer.parseInt(id));
//    		try {
//    			return checkIfBookingExists(booking);
//    		} catch (NoBookingFoundException invalidBookingIDException) {
//    			GetBookingResponseDTO getBookingResponseDTO = new GetBookingResponseDTO();
//    			getBookingResponseDTO.setError(new ErrorMessage(invalidBookingIDException.getMessage(), invalidBookingIDException.getErrorCode()));
//    			return new ResponseEntity<>(getBookingResponseDTO, HttpStatus.BAD_REQUEST);
//    		}
//    	}
//    	private ResponseEntity<GetBookingResponseDTO> checkIfBookingExists(Optional<Booking> booking) throws NoBookingFoundException {
//		if (booking.isPresent()) {
//			GetBookingResponseDTO getBookingResponseDTO = new GetBookingResponseDTO();
//			getBookingResponseDTO.setBooking(booking.get());
//			return new ResponseEntity<>(getBookingResponseDTO, HttpStatus.OK);
//		}
//
//		else
//			throw new NoBookingFoundException("Invalid Booking ID", "INV_EMPID");
//	}
}
