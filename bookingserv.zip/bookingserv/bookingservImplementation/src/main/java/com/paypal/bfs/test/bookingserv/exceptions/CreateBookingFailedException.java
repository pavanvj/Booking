package com.paypal.bfs.test.bookingserv.exceptions;

public class CreateBookingFailedException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 8369556143199339264L;
	private final String errorCode;

	public CreateBookingFailedException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;

	}

	public String getErrorCode() {
		return errorCode;
	}
}
