package com.paypal.bfs.test.bookingserv.exceptions;

public class NoBookingFoundException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3302286161901863050L;
	private final String errorCode;

	public NoBookingFoundException(String message, String errorCode) {
		super(message);
		this.errorCode = errorCode;

	}

	public String getErrorCode() {
		return errorCode;
	}
}
