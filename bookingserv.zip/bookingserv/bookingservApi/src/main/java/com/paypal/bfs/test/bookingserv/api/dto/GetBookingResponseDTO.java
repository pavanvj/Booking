package com.paypal.bfs.test.bookingserv.api.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.paypal.bfs.test.bookingserv.api.exceptions.ErrorMessage;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
@JsonInclude(Include.NON_EMPTY)

public class GetBookingResponseDTO {

		private ErrorMessage error;

		private List<Booking> booking;

		public List<Booking> getBooking() {
			return booking;
		}

		public void setBooking(List<Booking> booking) {
			this.booking = booking;
		}

		public ErrorMessage getError() {
			return error;
		}

		public void setError(ErrorMessage error) {
			this.error = error;
		}
}
