package com.paypal.bfs.test.bookingserv.api;

import javax.validation.Valid;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.paypal.bfs.test.bookingserv.api.dto.CreateBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.dto.GetBookingResponseDTO;
import com.paypal.bfs.test.bookingserv.api.model.Booking;

public interface BookingResource {
    /**
     * Create {@link Booking} resource
     *
     * @param booking the booking object
     * @return the created booking
     */

	@RequestMapping("v1/bfs/bookings")
	ResponseEntity<GetBookingResponseDTO> GetAllBookings();
	
	@PostMapping(value = "v1/bfs/booking", produces = { MediaType.APPLICATION_JSON_VALUE })
	ResponseEntity<CreateBookingResponseDTO> createBooking(@Valid @RequestBody Booking booking);

//	@RequestMapping("booking/{id}")
//	ResponseEntity<GetBookingResponseDTO> GetAllBookingsById(@PathVariable("id") String id);
}
